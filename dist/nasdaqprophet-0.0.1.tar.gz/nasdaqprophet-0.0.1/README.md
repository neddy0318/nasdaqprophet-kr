use this package for predicting nasdaq stocks and anticipated profit

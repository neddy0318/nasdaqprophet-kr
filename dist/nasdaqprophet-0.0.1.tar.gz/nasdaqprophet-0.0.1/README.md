use this package for predicting nasdaq stocks and anticipated profit for Korean Won-Dollor

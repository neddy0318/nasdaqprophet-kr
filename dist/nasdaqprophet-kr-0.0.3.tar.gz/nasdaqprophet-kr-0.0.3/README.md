use this for predicting nasdaq stock via prophet

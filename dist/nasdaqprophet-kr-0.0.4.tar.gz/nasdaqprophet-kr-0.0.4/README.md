use this for predicting nasdaq stock prices
